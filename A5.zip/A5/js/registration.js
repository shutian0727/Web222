function validateForm(){
            //return (validateUsername() && validateRePassword() && validatePassword() && PhoneNumber());
            return (validateUsername() && validatePassword() && validateRePassword() && PhoneNumber() && City() && validatePostCode());
}

function validateUsername(){
    var username =  document.getElementById('UserName').value;
    var userError = document.getElementById('UserError');
    userError.innerHTML = '';
    username = username.toUpperCase();
  

if (username.trim() == ''){
    userError.innerHTML = 'Username must be filled';
return false;}

else if (username.charAt(0) < 'A' || username.charAt(0) > 'Z'){
    userError.innerHTML = 'Username must start with a character';
return false;}

else if (username.length < 6){
    userError.innerHTML = 'Username must be at least 6 characters long';
    return false;
}
return true;}

    
    
function validatePassword(){
    var passwd =  document.getElementById('password').value;
    var pError = document.getElementById('passError');
    var flag1 = false;
    var flag2 = false;
    //var rv = false;
    
    pError.innerHTML = '';
    
    if (passwd.trim == ''){
        pError.innerHTML = '* Passowrd must be filled';
        return false;
    } else if( passwd[0] >=0 || passwd[0] <0){
        pError.innerHTML = "* Password - start with a letter";
        return false;
    } else if (passwd.length < 8){
        pError.innerHTML = "* Password - at least 8 characters";
        return false;
    } else {
        for (var i = 0; i < passwd.length; i++){
            if(passwd[i] >= 'A' && passwd[i] <= 'Z'){
                flag1 = true;
            }
        }
        if (flag1 === false) {
            pError.innerHTML = "* Password - must have 1 uppercase";
            return false;
        }
        
        for (var i = 0; i < passwd.length; i++){
            if(passwd[i] >= '0' && passwd[i] <= '9'){
                flag2 = true;
            }
        }
        if (flag2 === false) {
            pError.innerHTML = "* Password - must have 1 digit";
            return false;
        }
    }
      return true;
}
   




function validateRePassword(){
    var password =  document.getElementById('password').value.trim();
    var passwordRe =  document.getElementById('repassword').value.trim();
    var passwordErrorRe = document.getElementById('passErrorRe');
   


    //clearing html fields
    passwordErrorRe.innerHTML = '';
    //fieldStatus.innerHTML = '';
  

    if (passwordRe !== ''){
         if (passwordRe == password){
            passwordErrorRe.innerHTML = '';
            
            return true;
        } else {
            passwordErrorRe.innerHTML = 'Your passwords don\'t match';
            return false;
        }

    } else {
        passwordErrorRe.innerHTML = '';
        //fieldStatus.innerHTML = '';
      
        return false;
    }
}






function PhoneNumber(){

    //9  9  9  -  9  9  9  -  9  9  9  9
    //0  1  2  3  4  5  6  7  8  9 10 11
    var phoneNumber = document.getElementById('phone').value;
    var pError = document.getElementById('pError');
    var test = phoneNumber.match(/^\d{3}-\d{3}-\d{4}$/);
    if (test === null) {
        pError.innerHTML = "* Phone Number - must look like 111-111-1111";
        return false;
    }
    return true;
}
   
function City(){
    var city = document.getElementById('city').value;
    var cError = document.getElementById('cError');
    //var rv = true;

    for (var i = 0; i < city.length; i++) {
        if ((city[i] >= 'a' && city[i] <= 'z') || (city[i] >= 'A' && city[i] <= 'Z')) {
            cError.innerHTML = '';
        }
        else{
            cError.innerHTML = "* City - must be letters";
            return false;
        }
    }
    return true;
}
function validatePostCode(){
    var postcode =  document.getElementById('postcode').value;
    var postError = document.getElementById('postError');
    postError.innerHTML = '';
    postcode = postcode.toUpperCase();
    var test = postcode.match(/[A-Z][0-9][A-Z] ?[0-9][A-Z][0-9]/);

    if (postcode.length !== 6) {
        postError.innerHTML = 'Post Code must be at least 6 characters long';
        return false;
    }
    if (test === null){
        postError.innerHTML = 'Post Code format must be (Letter Digit Letter Digit Letter Digit)';
        return false;
    }

    return true;
}
   



function clearForm() {
    document.querySelector(".error").innerHTML = "";
}



   
