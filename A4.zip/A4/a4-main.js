/* Place all of your CSS Code in this file */

/********************************************************************************* 
*
* WEB222 – Assignment #4a
*
* I declare that this assignment is my own work in accordance with Seneca 
* Academic Policy. No part of this assignment has been copied manually or 
* electronically from any other source (including web sites) or distributed to 
* other students. 
* 
* Name: ____Shutian Xu_____________ Student ID: __109783175____________ Date: _____3/25/2018___________ 
* 
********************************************************************************/
var filterType = ""; // sets the filter type to "" (will later be dog, cat or bird)
var filterAgeMin = 0; // sets the filter age min to 0 (for no minimum age filter)
var filterAgeMax = Number.MAX_VALUE; // sets the filter age max to the largest number possible (for no maximum age filter)


// 1.Filter FUnction:loadTableWithFilters

function loadTableWithFilters(){
var Tablerow = document.querySelector('#main-table-body');//adding within <tbody>
Tablerow.innerHTML ='';
var text ='';
for( var i=0; i < petData.length; i++)
{
if (petData[i].type === filterType || filterType === "" && petData[i].age >= filterAgeMin && petData[i].age <= filterAgeMax)
    {
       text += "<tr><td> <img src='" + petData[i].image.src + "' alt='" + petData[i].image.alt + "' width='" + petData[i].image.width + "' height='" + petData[i].image.height + "'></td>";
       text += "<td><h4>" + petData[i].name + "</h4><p>" + petData[i].description + "</p><span>" + "Age:" + petData[i].age + " years old." + "</span></td></tr>" ;
    }
}
Tablerow.innerHTML = text;
}
window.onload = loadTableWithFilters;

//2.Function: filterDog
function filterDog(){
filterType= "dog";
loadTableWithFilters();
}

//3.Function: filterCat
function filterCats(){
    filterType = "cat";
    loadTableWithFilters();
}

//4.Function: filterBird
function filterBird(){
    filterType = "bird";
    loadTableWithFilters();
}

//5.Function: filter_zero_1
function filter_zero_1(){
    filterAgeMin = 0;
    filterAgeMax = 1;
    loadTableWithFilters();
}

//6.Function: filter_1_3
function filter_1_3(){
    filterAgeMin = 1;
    filterAgeMax = 3;
    loadTableWithFilters();
}

//7.Function: filter_4_plus
function filter_4_plus(){
    filterAgeMin = 4;
    filterAgeMax = Number.MAX_VALUE;
    loadTableWithFilters();
}
//8.Function:filterAllPets
function filterAllPets() {
    filterType ='';
    filterAgeMin = 0;
    filterAgeMax = Number.MAX_VALUE;
    loadTableWithFilters();
}

//filterAllPets();
//};//window.onload = function()
//function call
    //loadTableWithFilters( petData );


